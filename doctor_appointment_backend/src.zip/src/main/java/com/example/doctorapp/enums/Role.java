package com.example.doctorapp.enums;

public enum Role {
    USER,
    ADMIN,
    DOCTOR,
    PATIENT  // Add this if it's missing
}